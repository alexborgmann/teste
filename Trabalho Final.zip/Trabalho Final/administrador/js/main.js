// carregar a página "inicio.php" ao abrir o sistema
$('#conteudo').load('inicio.php');

// MODALS

	function abreModal() {
		$('#modal-ajuda').modal('show');
		// como uma das funções abaixo está como return false, deve-se declarar esta variavel como verdareira
		return true;
	}

	function modalSenha() {
		$('#modal-recSenha').modal('show');
	}

// FIM Modals

// Em caso de login incorreto, aparecerá este alerta
function erroLogin() {
	alert("Usuário ou senha incorretos!");
}
//-----------------------------------------------------------

// AJAX

// Ao clickar na sidebar abrirá uma página nova dentro do Index.php
$('ul.navegacao li a').click(function(e) {
	e.preventDefault();
	var pagina = $(this).attr('href');
	$('li').removeClass('active');
	$(this).parent().addClass('active');
	$.ajax({
		url: pagina + '.php',
		type: 'GET',
		data: '{ }',
		success: function(data) {
			$('#conteudo').html(data);
		}
	});
});

// Ao clickar no navbar mobile abrirá uma página nova dentro do Index.php
$('#subMenu a, .linkSeletor').click(function(e) {
	e.preventDefault();
	var pagina = $(this).attr('href');
	$.ajax({
		url: pagina + '.php',
		type: 'GET',
		data: '{ }',
		success: function(data) {
			$('#conteudo').html(data);
		}
	});
});




// FIM AJAX