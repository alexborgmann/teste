<?php
    require_once 'autentica.php';
    require_once 'dao/conexao.php';
    $modo = '';

    if (isset($_GET['cargoId'])) {
        $modo = 'edicao';
        $id = $_GET['cargoId'];

        $queryCargo = sprintf("SELECT * FROM cargo WHERE cargo_id=%s", $id);
        $cargos = mysql_query($queryCargo, $con) or die(mysql_error());
        $cargo = mysql_fetch_assoc($cargos);
        $nome = $cargo['cargo_nome'];
      }

      else {
        $modo = 'insercao';
      }
       
?>

<div class="">
    <div class="col-xs-10 col-xs-offset-1 col-sm-6 col-sm-offset-3 text-left" id="conteudo-formulario">
        <form method="post" class="form-horizontal form-persistencia" id="form-insert">
            <?php if ($modo == 'edicao') {
                echo '<input type="hidden" name="id" value="<?php echo $id; ?>">';
            }?>

            <div class="form-group">
                <label class="control-label">Nome:(*)</label>
                <input type="text" class="form-control" name="nome" id="nome" autofocus value="<?php if($modo == 'edicao') {echo $nome;} ?>">
            </div>

            <div class="row" style="margin-top: 15px;">
                <div class="col-xs-6 col-sm-6 text-left">
                    <a href="Javascript:void(0);" class="btn btn-lg btn-default" onclick="$('#conteudo-formulario').remove();">
                        <span class="glyphicon glyphicon-remove"></span>
                        Fechar
                    </a>
                </div>

                <div class="col-xs-6 col-sm-6 text-right">
                    <button type="button" name="submit" class="btn btn-lg btn-warning" onclick="verificaFormulario()" disabled id="salvar">
                        <span class="glyphicon glyphicon-ok"></span>
                        Salvar
                    </button>
                </div>
            </div>
            <div id="submeter"></div>
            <input type="hidden" name="id" value="<?php if($modo == 'edicao') {echo $id;} ?>">
            <input type="hidden" name="modo" value="<?php if($modo == 'edicao') {echo 'edicao';} else if($modo == 'insercao') {echo 'insercao';} ?>">
            <input type="hidden" name="tabela" value="cargo">
        </form>
    </div>
</div>
<script>
    var $tabela = $('#tabela');
    var $formulario = $('#form-insert');
    var $validaEmail = /^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$/i;

    $(document).ready(function() {
        var erro = false;
        $('#nome').blur(function() {
           if($('#nome').val() !== "") {
              erro = false
              $('#salvar').removeAttr('disabled');
            } else {
              erro = true
            }
        });
    });

    function verificaFormulario() {
            if($("#nome").val()==null || $("#nome").val()=='') {
                $("#nome").css('border', '2px solid #ff0000');
                $("#nome").focus();
            } else { 
                submeter(); 
            }
        }

    function submeter() {
        $.ajax({
            url: 'dao/persistencia.php',
            type: 'POST',
            data: $('#form-insert').serialize(),
            success: function(data) {
                $('#submeter').html(data);
                $tabela.bootstrapTable('refresh');
                alert("Cargo cadastrado com sucesso!");
                $formulario[0].reset();
            }
        }); 
    };
</script>