<?php
    session_start();  // a sessão só pode ser terminada se ela primeiro for iniciada
    session_destroy();
    header("Location: index.php");
    exit();
?>