<?php
  require_once 'autentica.php';
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <title>Og Panel 3.5</title>
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
    <meta name="viewport" content="width=device-width, initial-scale=1">
	
	  <script src="js/jquery.min.js"></script>
    
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <script src="bootstrap/js/bootstrap.min.js"></script>
    
    <link href='css/css.css' rel='stylesheet' type='text/css'>
    <link href='css/style.css' rel='stylesheet' type='text/css'>

	  <link rel="icon" href="images/favicon.png" type="image/x-icon">
    <link rel="stylesheet" href="bootstrap/table/bootstrap-table.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.form/4.2.2/jquery.form.min.js" integrity="sha384-FzT3vTVGXqf7wRfy8k4BiyzvbNfeYjK+frTVqZeNDFl8woCbF0CYG6g2fMEFFo/i" crossorigin="anonymous"></script>
    
</head>

<body>
<?php include 'nav.php'; ?>
<div class="container-fluid conteudo-site">
  <?php include 'sidebar.php'; ?>
  <div class="col-md-9 center" id="conteudo" style="height: calc(100vh - 51px); overflow-y: auto;">
  
  </div>
</div>

<!-- Scripts Personalizados -->
<script src="js/main.js"></script>
</body>
</html>