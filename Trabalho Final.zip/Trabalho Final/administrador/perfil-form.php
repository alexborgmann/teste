<?php
    require_once 'autentica.php';
    require_once 'dao/conexao.php';

    if (!function_exists("GetSQLValueString")) {
      function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
      {
        if (PHP_VERSION < 6) {
          $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
        }

        $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

        switch ($theType) {
          case "text":
          $theValue = ($theValue != "") ? "'" . trim($theValue) . "'" : "NULL";
          break;    
          case "long":
          case "int":
          $theValue = ($theValue != "") ? intval($theValue) : "NULL";
          break;
          case "double":
          $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
          break;
          case "date":
          $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
          break;
          case "defined":
          $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
          break;
        }
        return $theValue;
      }
    }

    $user = GetSQLValueString($_SESSION['login'], 'text');
    $queryUsuarioL = sprintf("SELECT * FROM usuario WHERE user_login= %s",$user);
    $usuariosL = mysql_query($queryUsuarioL, $con) or die(mysql_error());
    $usuarioL = mysql_fetch_assoc($usuariosL);
    
    $modo  = 'edicao';
    $id    = $usuarioL['user_id'];
    $nivel = $usuarioL['user_nivel'];
    $nome  = $usuarioL['user_nome'];
    $login = $usuarioL['user_login'];
    $senha = $usuarioL['user_senha'];
    $email = $usuarioL['user_email'];
    $foto  = $usuarioL['user_foto'];
       
?>

<div class="col-sm-6 col-sm-offset-3 col-xs-10 col-xs-offset-1 text-left" id="conteudo-formulario">
    <div class="titulo text-center" style="margin-top: 20px; margin-bottom: 20px;">
        <span class="text-uppercase corLaranja">perfil</span>
    </div>

    <form method="post" class="form-horizontal form-persistencia" id="form-insert" action="dao/persistencia.php" enctype="multipart/form-data">
        <?php echo '<input type="hidden" name="id" value="' . $id . '"> ';?>
        <div class="form-group">
            <label class="control-label">Nome:</label>
            <input type="text" class="form-control" name="nome" id="nome" readonly value="<?php echo $nome; ?>">
        </div>

        <div class="form-group">
            <label class="control-label">Login:</label>
            <input type="text" class="form-control" name="login" id="login" readonly value="<?php echo $login; ?>">
        </div>

        <div class="form-group">
            <label class="control-label">Senha Antiga:(*)</label>
            <input type="password" class="form-control" name="senhaAntiga" id="senhaAntiga" value="">
        </div>

        <div class="form-group">
            <label class="control-label">Senha Nova:(*)</label>
            <input type="password" class="form-control" name="senha" id="senha" value="">
        </div>

        <div class="form-group">
            <label class="control-label">Confirmar Senha:(*)</label>
            <input type="password" class="form-control" name="senhaNova" id="senhaNova" value="">
        </div>

        <div class="form-group">
            <label class="control-label">E-Mail:</label>
            <input type="text" class="form-control" name="email" id="email" value="<?php echo $email; ?>" readonly>
        </div>

        <?php if(isset($foto)) { ?>
          <div class="col-xs-6" style="padding-bottom: 20px;">
            <label>Foto Atual:</label>
            <img src="imagens/imagens_usuario/<?php echo $foto; ?>" style="width: 100%;">
          </div>
          <div class="col-xs-6">
            <input type="file"  name="foto" id="foto" style="margin-top: 100px;" value="">
          </div>
        <?php } else { ?>
        <div class="form-group">
            <label class="control-label">Foto:</label>
            <input type="file"  name="foto" id="foto" value="">
        </div>
        <?php } ?>

        <div class="col-xs-12">
                <div class="col-xs-6 col-sm-6 text-left">
                    <a href="index.php" class="btn btn-lg btn-default">
                        <span class="glyphicon glyphicon-remove"></span>
                         Cancelar
                    </a>
                </div>

                <div class="col-xs-6 col-sm-6 text-right">
                    <button disabled type="button" name="submit" id="submit" class="btn btn-lg btn-warning" onclick="verificaFormulario()">
                        <span class="glyphicon glyphicon-ok"></span>
                         Salvar
                    </button>
                </div>
        </div>
        <div id="submeter"></div>
        <input type="hidden" name="id" value="<?php echo $id; ?>">
        <input type="hidden" name="modo" value="<?php echo 'edicao'; ?>">
        <input type="hidden" name="tabela" value="usuario">
    </form>
</div>
<script>
    var $tabela = $('#tabela');
    var $formulario = $('#form-insert');

    $(document).ready(function() {
        var erro = false;
        $("#senha, #senhaNova, #foto").blur(function() {
            if ($("#nome").val() !== "" && $("#login").val() !== "" && $("#email").val() !== "" || $("#admin").is(":checked") || $("#usuario").is(":checked")) {
                erro = false
                $("#submit").removeAttr('disabled');
            } else {
                erro = true
            }
        });
    });

    function verificaFormulario() {
            if($("#senhaAntiga").val()==null || $("#senhaAntiga").val()=='') {
                $("#senhaAntiga").css('border', '2px solid #ff0000');
                $("#senhaAntiga").focus();
            } else if($("#senha").val()==null || $("#senha").val()=='') {
                $("#senha").css('border', '2px solid #ff0000');
                $("#senha").focus();
            } else if($("#senhaNova").val()==null || $("#senhaNova").val()=='') {
                $("#senhaNova").css('border', '2px solid #ff0000');
                $("#senhaNova").focus();
            } else if($("#senhaAntiga").val()!=<?php echo $senha; ?> ) {
                alert('Senha atual inválida.');
                $("#senhaAntiga").focus();
            } else if ($("#senha").val() != $("#senhaNova")) {
                alert('Campos: Senha Nova e Confirmar Senha estão divergentes.')
                $("#senha").focus();
                $("#senhaNova").css('border', '2px solid #ff0000');
            }
             else { 
                submeter(); 
            }
        }

    function submeter() {
        $("#form-insert").ajaxSubmit().data('jqxhr').done(function(data,status,xhr){
          $('#submeter').html(data);
          alert("A <?php echo $modo; ?> foi realizada com sucesso.");
          $formulario[0].reset();
          $tabela.bootstrapTable('refresh');
       }).fail(function(err,status,xhr){
          alert("Erro na persistencia");
       }); 
    };
</script>