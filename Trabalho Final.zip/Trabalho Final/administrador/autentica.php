<?php
	if (!isset($_SESSION)) {
	    session_start();
	}
	//$_SESSION['login'] = $_SESSION['login'];
	//echo $_SESSION['login'];
	//exit();
    if(!isset($_SESSION['login'])){
        header("Location: login.php");
        exit();
    }
?>