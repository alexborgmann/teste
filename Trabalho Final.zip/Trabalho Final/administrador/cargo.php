<!-- Definir dados do JSON -->
<?php 
  session_start();
  $_SESSION["tabela"] = "cargo";
?>
<!-- FIM Definir dados do JSON -->

<div class="text-left">
  <ol class="breadcrumb">
    <li><a href="index.php" class="text-uppercase">home</a></li>
    <li class="active text-uppercase">Cargo</li>
  </ol>
</div>
<div class="titulo">
  <span class="text-uppercase corLaranja">cargo</span>
</div>
<div class="conteudo-pagina">
  <div class="text-right" style="margin-top: 10px;">
    <a href="Javascript:void(0);" class="btn-lg btn-primary" onclick="inserir()">
      <span class="glyphicon glyphicon-plus"></span>
      Adicionar
    </a>
  </div>
  <table data-pagination="true" data-pagination-v-align="bottom" data-search="true" data-trim-on-search data-toggle="table" data-url="dao/dados.php" data-striped="true" data-sort-name="cargo_nome" data-smart-display data-search-align="right" id="tabela">
    <thead>
      <tr>  
        <th data-sortable="true" data-field="cargo_nome" data-align="center">Nome</th>
        <th data-formatter="btnFormater" data-align="center" value="user_id">Ação</th>
      </tr>
    </thead>
  </table>
  
  <div id="formulario">
    
  </div>
</div>
<script>
  var $tabela = $('#tabela');

  function inserir() {
      $.ajax({
        url: 'cargo-form.php',
        type: 'GET',
        data: '{ }',
        success: function(data) {
          $('#formulario').html(data);
        }
      });
  }

  function editar(id) {
    $.ajax({
      url: 'cargo-form.php',
      type: 'GET',
      data: {cargoId: id},
      success: function(data) {
        $('#formulario').html(data);
      }
    });
  }

  function excluir(id) {
    var confirmar = confirm("Tem certeza que deseja excluir este Cargo?");
    if (confirmar == true) {
      $.ajax({
      url: 'dao/persistencia.php',
      type: 'POST',
      data: {id: id, tabela: 'cargo', modo: 'exclusao'},
      success: function(data) {
        alert("Cargo deletada com sucesso!");
        $tabela.bootstrapTable('refresh');
      }
    })
    } else {
      return false;
    }    
  }

      // ações dos itens da tabela
    function btnFormater(value,row) {
      return '<a class="btn btn-warning" id="btn-editar" name="editar" title="Editar item" href="Javascript:void(0);" onclick="editar('+row.cargo_id+')"><span class="glyphicon glyphicon-edit"></span></a>' 
      + '<button class="btn btn-danger" name="excluir" title="Excluir item" style="margin: 0 0 0 5px;" onclick="excluir('+row.cargo_id+')"><span class="glyphicon glyphicon-trash"></span></button>';
    }
</script>

<!-- Bootstrap-table -->
<script src="bootstrap/table/bootstrap-table.js"></script>
<script src="bootstrap/table/bootstrap-table-pt-BR.js"></script>