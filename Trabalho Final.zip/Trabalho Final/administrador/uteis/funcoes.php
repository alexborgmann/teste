<?php
// ----------------------- FUN��O DE UPLOAD ---------------------------
function upload($destino, $arquivo, $nomeEnviado = "") {
	$char = array(" ", "/", "~", "`", "'", "!", "@", "#", "$", "%", "^", "&", "*", "(", ")");
	
	$name = strtolower($arquivo['name']);
	
	//Retira a exten��o do arquivo
	$tipo = explode('.', $name); // Quebra o nome no(s) ponto(s)
	$extencao = '.'.$tipo[count($tipo)-1]; // Pega a exten��o do arquivo
	
	$name = $tipo[0];
	
	//Retira os acentos
	$name = preg_replace("[^a-zA-Z0-9 ]", "",
			strtr($name, "�������������������������� ", "aaaaeeiooouucAAAAEEIOOOUUC "));

	
	$name = str_replace($char, "_", $name);

	$datahora = date("Ymd_His_");

	$name = $datahora.$name.$extencao;
	
	//Se o nome for enaviado por parametro
	if($nomeEnviado != "")
		$name = $nomeEnviado;
	
	$uploaddir = $destino;
	$uploadfile = $uploaddir.$name;

	if ( move_uploaded_file($arquivo['tmp_name'], $uploadfile) ) 
    	return $name;
	else
    	return 0;
}

//::::::::::::::::::::::::::::::::::::: FUNCAO PARA NOME UNICO - PADRAO URL AMIGAVEL :::::::::::::::::::::::::
function nomeUnicoUrlAmigavel($nome=NULL, $comMD5=false) {
	
	$nomeFinal = '';
	
	if ($nome) {
		$trocarIsso	= array('�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','�','O','�','�','�','�', "\r\n");
		$porIsso	= array('a','a','a','a','a','a','c','e','e','e','e','i','i','i','i','n','o','o','o','o','o','u','u','u','y','A','A','A','A','A','A','C','E','E','E','E','I','I','I','I','N','O','O','O','O','O','O','U','U','U','Y', ' ');
		$nome = str_replace($trocarIsso, $porIsso, $nome);
		
		// Remove tudo o que n�o for letras ou espacos
		$nome = preg_replace("/[^a-zA-Z ]/i", "", $nome);
		// Isso remove os espacos duplicados, deixando apenas um espa�o em branco.
		$nome = preg_replace('/\s(?=\s)/', '', trim($nome));
		// Substitui os espacos por ifens
		$nomeFinal = str_replace(' ', '-', $nome);
	}
	else
		$nomeFinal = md5(uniqid(time()));
	
	if (($nome) && ($comMD5))
		$nomeFinal = time().'-'.$nomeFinal;
	
	return substr($nomeFinal, 0, 200);
}

?>