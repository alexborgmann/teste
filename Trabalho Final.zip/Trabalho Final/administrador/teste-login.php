<?php 
    class testSimple_add extends \PHPUnit_Framework_TestCase {

        private function _execute(array $params = array()) {
            $_POST = $params;
            ob_start();
            include 'login.php';
            return ob_get_clean();
        }

        public function testSomething() {
            $args = array('arg1'=>30, 'arg2'=>12);
            $this->assertEquals(42, $this->_execute($args)); // passes

            $args = array('arg1'=>-30, 'arg2'=>40);
            $this->assertEquals(10, $this->_execute($args)); // passes

            $args = array('arg1'=>-30);
            $this->assertEquals(10, $this->_execute($args)); // fails
        }

    }
?>