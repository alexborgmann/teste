<?php
	require_once 'dao/conexao.php';

	if (!function_exists("GetSQLValueString")) {
	  function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
	  {
	    if (PHP_VERSION < 6) {
	      $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
	    }

	    $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

	    switch ($theType) {
	      case "text":
	      $theValue = ($theValue != "") ? "'" . trim($theValue) . "'" : "NULL";
	      break;    
	      case "long":
	      case "int":
	      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
	      break;
	      case "double":
	      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
	      break;
	      case "date":
	      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
	      break;
	      case "defined":
	      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
	      break;
	    }
	    return $theValue;
	  }
	}

	$queryTabela = "SELECT * FROM tabelas WHERE tab_status = 1 ORDER BY tab_posit";
	$tabelas = mysql_query($queryTabela, $con) or die(mysql_error());

	$user = GetSQLValueString($_SESSION['login'], 'text');
	$queryUsuario = sprintf("SELECT * FROM usuario WHERE user_login= %s",$user);
	$usuarios = mysql_query($queryUsuario, $con) or die(mysql_error());
	$usuario = mysql_fetch_assoc($usuarios);
?>
<link rel="stylesheet" href="font-awesome/css/fontawesome-all.min.css">
<!-- Navbar -->
<nav id="navbar" class="navbar navbar-fixed-top navbar-orange hidden-xs hidden-sm">
	<div class="container">
		<div class="collapse navbar-collapse">
			<ul class="nav navbar-nav">
				<li><a href="index.php" class="text-uppercase"><span class="glyphicon glyphicon-home"></span> inicio</a></li>
				<li><a href="../index.php" target="_blank" class="text-uppercase"><span class="glyphicon glyphicon-new-window"></span> ir para o site</a></li>
				<li><a href="Javascript:void(0);" class="text-uppercase" data-toggle="modal" data-target="#modalAjuda"><span class="glyphicon glyphicon-question-sign"></span> ajuda</a></li>
			</ul>
			<ul class="nav navbar-nav navbar-right">
				<li>
					<?php 
						if (isset($usuario['user_foto'])) {
							echo '<img src="imagens/imagens_usuario/' . $usuario['user_foto'] . '" style="border-radius: 500px; height: 30px; margin-top: 10px;">';
						} else {
							echo '<img src="imagens/imagens_usuario/avatar_default.jpg" style="border-radius: 50%; height: 30px; margin-top: 10px;">';
						}
					?>
				</li>
				<li>
					<a href="Javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" aria-haspoupup="true" aria-expanded="false"><?php echo $usuario['user_nome']; ?> <span class="caret"></span></a>
					<ul class="dropdown-menu">
						<li><a href="perfil-form" class="linkSeletor"><span class="glyphicon glyphicon-user"></span> Visualizar perfil</a></li>
						<li><a href="logout.php"><span class="glyphicon glyphicon-off"></span> Sair</a></li>
					</ul>
				</li>
			</ul>
		</div>
	</div>
</nav>
<!-- Fim Navbar -->

<!-- Navbar Mobile -->
<div class="visible-xs visible-sm navbar-orange">
	<div class="container" style="height: 80px;">
		<div class="col-xs-12" style="margin-top: 10px;">
			<div style="float: right; margin-top: 20px;" onclick="$('#subMenu').slideToggle(500)">
				<img src="images/menu.png">
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
</div>
<!-- FIM Navbar Mobile -->

<!-- SubMenu Mobile -->
<div id="subMenu" class="submenu navbar-orange">
	<div class="text-center" style="border-bottom: solid 1px #DDDDDD;">
		<a class="text-uppercase t20" href="inicio" style="line-height: 40px;">inicio</a> <br>
		<?php while ($tabelaN = mysql_fetch_assoc($tabelas)) { ?>
			<a class="text-uppercase t20" href="<?php echo $tabelaN['tab_nome']; ?>"><?php echo $tabelaN['tab_titulo']; ?></a> <br>
		<?php } ?>
	</div>
	<div class="text-center">
		<a class="text-uppercase t20" href="perfil-form"><span class="glyphicon glyphicon-user"></span> <?php echo $usuario['user_nome']; ?></a> <br>
		<button class="btn-lg text-uppercase t20" style="color: #FFF; background-color: transparent; border-color: transparent;" onclick="window.location.href='logout.php'"><span class="glyphicon glyphicon-off"></span> sair</button>
	</div>
</div>
<!-- FIM SubMenu Mobile -->

<!-- Modal Ajuda -->
<div class="modal fade" id="modalAjuda" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Ajuda</h4>
      </div>
      <div class="modal-body">
    	<p class="t16 text-center" style="line-height: 30px;">
	        <a href="http://tecnologia.orange.net.br/" target="_blank"><i class="fas fa-link"></i> Site Oficial</a> <br>
	        <i class="fas fa-phone corPreto"></i> (54)3344-3062 <br>
	        <i class="fab fa-facebook"></i> orange.inovacao <br>
	        <i class="fas fa-at"></i> tecnologia@orange.net.br <br>
	        <a href="https://www.google.com.br/maps/place/Orange+Tecnologia+para+Internet/@-28.068774,-52.0129337,17z/data=!3m1!4b1!4m5!3m4!1s0x94e25f43345b57c3:0x10d3c3bc2d4a032e!8m2!3d-28.068774!4d-52.010745?dcr=0" target="_blank"> <i class="fas fa-map-marker-alt"></i> Av. Sete de Setembro. 1379, Sala 303 <br> Tapejara - RS 99950-000 </a>
  		</p>
      </div>
      <div class="modal-footer">
        <p class="t14 text-center">
        	<span class="corLaranja fw700">Orange Tecnologia para Internet &copy; 2018</span> - Todos os direitos reservados. <br>
        	Proibida a reprodução parcial ou total, por qualquer meio. Protegido pela lei do direito autoral.
        </p>
      </div>
    </div>
  </div>
</div>
<!-- FIM Modal Ajuda -->