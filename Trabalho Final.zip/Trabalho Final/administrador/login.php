<?php 
	require_once 'dao/conexao.php';

	if (isset($_POST['login'])&& isset($_POST['senha'])) {
		$login = $_POST['login'];
		$senha = md5($_POST['senha']);

		$erro = 'Usuário ou senha incorretos!';

		$select = mysql_select_db("alex") or die("Sem acesso ao banco de dados, favor contatar o administrador!");

	 
		$result = mysql_query("SELECT * FROM usuario WHERE user_login = '$login' AND user_senha = '$senha'");
		if(mysql_num_rows($result) > 0) {
			$erro = false;
			$_SESSION['login'] = $login;
			$_SESSION['senha'] = $senha;
			header('location: index.php');
		} else {
			unset($_SESSION['login']);
			unset($_SESSION['senha']);
			$_SESSION["erro"] = $erro;
			header('location: login.php');
		}
	}
	

?>
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <title>Faça seu login</title>
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
    <meta name="viewport" content="width=device-width, initial-scale=1">
	
	<script src="js/jquery.min.js"></script>
    
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <script src="bootstrap/js/bootstrap.min.js"></script>
    
    <link href='css/css.css' rel='stylesheet' type='text/css'>
    <link href='css/style.css' rel='stylesheet' type='text/css'>

	<link rel="icon" href="images/favicon.png" type="image/x-icon">
</head>
<body>
	<div class="parallax">
		<div class="container" style="padding-top: 150px;">
			<div class="login">
				<div class="login-header">
					<span style="margin-left: 5px;" class="corLaranja t14">Administrator 2.0</span>
				</div>
				<div class="container-fluid login-body">
					<form method="post" action="" id="formlogin" name="formlogin" class="form-signin center">
						<input type="text" class="form-control input-lg" placeholder="Login" name="login" id="login" required>
						<input type="password" class="form-control input-lg" placeholder="Senha" name="senha" id="senha" required>	
						<input class="btn-lg btn-login btn-warning" type="submit" value="LOGAR" name="logar"></input>
					</form>
				</div>

			</div>
			<?php
				if (isset($_SESSION["erro"])) {
					$erro = $_SESSION["erro"];
					echo '<div class="alert alert-danger login-erro">'.$erro.'</div>';
				}
			?>
		</div>
	</div>

	<!-- Modal Ajuda -->
	<div id="modal-recSenha" class="modal fade" role="dialog" aria-labelledby="Recuperar senha">
		<div class="modal-dialog modal-sm" role="document">
			<div class="modal-content">
		      <div class="modal-header">
		        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
		        <h4 class="modal-title">Recuperar senha</h4>
		      </div>
		      <div class="modal-body">
		      	<span class="t14">Insira seu E-Mail no campo abaixo, uma nova senha será gerada para você.</span> <br>
		      	<form style="margin: 10px 0 10px 0;">
		      		<input class="form-control" type="text" id="rec_email" placeholder="E-Mail">
		      	</form>
		      </div>
		      <div class="modal-footer">
	        	<button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
	        	<button type="button" class="btn btn-primary">Enviar</button>
		      </div>
		    </div><!-- /.modal-content -->
		    </form>
		</div>
	</div>
	<!-- FIM Modal Ajuda -->

<!-- jQuery -->
<script src="js/main.js"></script>
</body>
</html>

<?php
	unset($_SESSION["erro"]);
?>