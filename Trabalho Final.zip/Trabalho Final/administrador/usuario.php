<!-- Definir dados do JSON -->
<?php 
  session_start();
  $_SESSION["tabela"] = "usuario";
?>
<!-- FIM Definir dados do JSON -->

<div class="text-left">
  <ol class="breadcrumb">
    <li><a href="index.php" class="text-uppercase">home</a></li>
    <li class="active text-uppercase">Usuário</li>
  </ol>
</div>
<div class="titulo">
  <span class="text-uppercase corLaranja">usuário</span>
</div>
<div class="conteudo-pagina">
  <div class="text-right" style="margin-top: 10px;">
    <a href="Javascript:void(0);" class="btn-lg btn-primary" onclick="inserir()">
      <span class="glyphicon glyphicon-plus"></span>
      Adicionar
    </a>
  </div>
  <table data-pagination="true" data-pagination-v-align="bottom" data-search="true" data-trim-on-search data-toggle="table" data-url="dao/dados.php" data-striped="true" data-sort-name="user_nome" data-smart-display data-search-align="right" id="tabela">
    <thead>
      <tr>  
        <th data-sortable="true" data-field="user_nome" data-align="center">Nome</th>
        <th data-sortable="true" data-field="user_login" data-align="center">Login</th>
        <th data-sortable="true" data-field="user_email" data-align="center">E-Mail</th>
        <th data-sortable="true" data-field="user_nivel" data-align="center">Nível</th>
        <th data-formatter="btnFormater" data-align="center" value="user_id">Ação</th>
      </tr>
    </thead>
  </table>
  <div id="formulario">
    
  </div>
</div>
<script>
  var $tabela = $('#tabela');

  function inserir() {
      $.ajax({
        url: 'usuario-form.php',
        type: 'GET',
        data: '{ }',
        success: function(data) {
          $('#formulario').html(data);
        }
      });
  }

  function editar(id) {
    $.ajax({
      url: 'usuario-form.php',
      type: 'GET',
      data: {userId: id},
      success: function(data) {
        $('#formulario').html(data);
      }
    });
  }

  function excluir(id) {
    var confirmar = confirm("Tem certeza que deseja excluir este Usuário?");
    if (confirmar == true) {
      $.ajax({
      url: 'dao/persistencia.php',
      type: 'POST',
      data: {userId: id, tabela: 'usuario', modo: 'exclusao'},
      success: function(data) {
        alert("Usuário deletado com sucesso!");
        $tabela.bootstrapTable('refresh');
      }
    })
    } else {
      return false;
    }    
  }

      // ações dos itens da tabela
    function btnFormater(value,row) {
      return '<a class="btn btn-warning" id="btn-editar" name="editar" title="Editar item" href="Javascript:void(0);" onclick="editar('+row.user_id+')"><span class="glyphicon glyphicon-edit"></span></a>' 
      + '<button class="btn btn-danger" name="excluir" title="Excluir item" style="margin: 0 0 0 5px;" onclick="excluir('+row.user_id+')"><span class="glyphicon glyphicon-trash"></span></button>';
    }
</script>

<!-- Bootstrap-table -->
<script src="bootstrap/table/bootstrap-table.js"></script>
<script src="bootstrap/table/bootstrap-table-pt-BR.js"></script>