<?php
    require_once 'autentica.php';
    require_once 'dao/conexao.php';
    $modo = '';

    if (isset($_GET['prodId'])) {
        $modo = 'edicao';
        $id = $_GET['prodId'];

        $queryProduto = sprintf("SELECT * FROM estoque WHERE prod_id=%s", $id);
        $produtos = mysql_query($queryProduto, $con) or die(mysql_error());
        $produto = mysql_fetch_assoc($produtos);
        $nome = $produto['prod_nome'];
        $quantidade = $produto['prod_quant'];
      }

      else {
        $modo = 'insercao';
      }
       
?>

<div class="col-xs-10 col-xs-offset-1 col-sm-6 col-sm-offset-3 text-left" id="conteudo-formulario">
    <form method="post" class="form-horizontal form-persistencia" id="form-produto" action="dao/persistencia.php" enctype="multipart/form-data">
        <?php if ($modo == 'edicao') {
            echo '<input type="hidden" name="id" value="<?php echo $id; ?>">';
        }?>

        <div class="form-group">
            <label class="control-label">Nome:(*)</label>
            <input type="text" class="form-control" name="nome" id="nome" autofocus value="<?php if($modo == 'edicao') {echo $nome;} ?>">
        </div>

        <div class="form-group">
            <label class="control-label">Quantidade:(*)</label>
            <input type="number" class="form-control" name="quantidade" id="quantidade" min="0" max="100" step="0.1" value="<?php if($modo == 'edicao') {echo $quantidade;} ?>">
        </div>

        <div class="col-xs-12">
                <div class="col-xs-6 col-sm-6 text-left">
                    <a href="Javascript:void(0);" class="btn btn-lg btn-default" onclick="$('#conteudo-formulario').remove();">
                        <span class="glyphicon glyphicon-remove"></span>
                        Fechar
                    </a>
                </div>

                <div class="col-xs-6 col-sm-6 text-right">
                    <button disabled type="button" name="submit" id="submit" class="btn btn-lg btn-warning" onclick="verificaFormulario()">
                        <span class="glyphicon glyphicon-ok"></span>
                        Salvar
                    </button>
                </div>
        </div>
        <div id="submeter"></div>
        <input type="hidden" name="modo" value="<?php if($modo == 'edicao') {echo 'edicao';} else if($modo == 'insercao') {echo 'insercao';} ?>">
        <input type="hidden" name="tabela" value="estoque">
        <?php if ($modo == 'edicao') { ?>
            <input type="hidden" name="id" value="<?php echo $id; ?>">
        <?php } ?>
    </form>
</div>
<script>
    var $tabela = $('#tabela');
    var $formulario = $('#form-produto');
    var filtroEmail = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;

    $(document).ready(function() {
        var erro = false;
        $("#nome, #quantidade").blur(function() {
            if ($("#nome").val() !== "" && $("#quantidade").val() !== "" ) {
                erro = false
                $("#submit").removeAttr('disabled');
            } else {
                erro = true
            }
        });
    });

    function verificaFormulario() {
            if($("#nome").val()==null || $("#nome").val()=='') {
                $("#nome").css('border', '2px solid #ff0000');
                $("#nome").focus();
            } else if($("#quantidade").val()==null || $("#quantidade").val()=='') {
                $("#quantidade").css('border', '2px solid #ff0000');
                $("#quantidade").focus();
            } else { 
                submeter(); 
            }
        }

    function submeter() {
        $("#form-produto").ajaxSubmit().data('jqxhr').done(function(data,status,xhr){
          $('#submeter').html(data);
          alert("A <?php echo $modo; ?> foi realizada com sucesso.");
          $formulario[0].reset();
          $tabela.bootstrapTable('refresh');
       }).fail(function(err,status,xhr){
          alert("Erro na persistencia");
       }); 
    };
</script>
