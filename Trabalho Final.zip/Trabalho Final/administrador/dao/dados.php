<?php
	require_once 'conexao.php';

	// TABELA DE DADOS
	switch ($_SESSION['tabela']) {
		case 'usuario':
			$queryDados = sprintf("SELECT * FROM usuario ORDER BY user_nome");
			break;
		
		case 'pessoa':
			$queryDados = sprintf("SELECT * FROM pessoas ORDER BY pess_nome");
			break;

		case 'cargo':
			$queryDados = sprintf("SELECT * FROM cargo ORDER BY cargo_nome");
			break;

		case 'estoque':
			$queryDados = sprintf("SELECT * FROM estoque ORDER BY prod_nome");
			break;

		case 'filial':
			$queryDados = sprintf("SELECT * FROM filial ORDER BY filial_nome");
			break;

		case 'funcionario':
			$queryDados = sprintf("SELECT * FROM funcionario
								   LEFT OUTER JOIN cargo ON func_id_cargo = cargo_id
								   GROUP BY func_id
			 					   ORDER BY func_nome");
			break;
	}

	$dados = mysql_query($queryDados, $con) or die(mysql_error());

	$json_array = array();
	while ($dado = mysql_fetch_assoc($dados)) {
		$json_array[] = $dado;
	}

	echo json_encode($json_array);
?>