<?php
    require_once 'conexao.php';
    include '../uteis/funcoes.php';

    // função para proteger contra MYSQL Inject
    if (!function_exists("GetSQLValueString")) {
    function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
    {
      if (PHP_VERSION < 6) {
        $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
      }

      $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

      switch ($theType) {
        case "text":
          $theValue = ($theValue != "") ? "'" . trim($theValue) . "'" : "NULL";
          break;    
        case "long":
        case "int":
          $theValue = ($theValue != "") ? intval($theValue) : "NULL";
          break;
        case "double":
          $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
          break;
        case "date":
          $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
          break;
        case "defined":
          $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
          break;
      }
      return $theValue;
    }
    }
    // FIM MySQL Inject

  switch ($_POST['tabela']) {
    // ==================================== USUARIO ===========================================================
    case 'usuario':
      // Insert -------------------------------------------------------------------------------------------
      if ($_POST['modo'] == 'insercao') {
           if (isset($_FILES['foto'])) {
              // pegar o nome do arquivo, name é um atributo de vetor que está salvo
              $imgName = $_FILES['foto']['name'];
              $imgTmpName = $_FILES['foto']['tmp_name'];
              $imgSize = $_FILES['foto']['size'];
              $imgError = $_FILES['foto']['error'];
              $imgType = $_FILES['foto']['type'];

              $imgExt = explode('.', $imgName);
              $imgActualExt = strtolower(end($imgExt));

              // informação das extensões permitidas de arquivo
              $permitido = array('jpg', 'jpeg', 'png', 'pdf');

              // se o tipo da imagem está dentro do permitido 
              if (in_array($imgActualExt, $permitido)) {
                // verificar se não tem erros na imagem
                if ($imgError === 0) {
                  // se o tamanho do arquivo for menor que 50mb
                  if ($imgSize < 100000) {
                    $imgNameNew = str_replace(" ", "", strtolower($_POST['nome'])).".".$imgActualExt;
                    $imgDestination = '../imagens/imagens_usuario/' . $imgNameNew;
                    // Move o arquivo enviado dos arquivos temporarios para o destinatario abaixo
                    move_uploaded_file($imgTmpName, $imgDestination);
                  } else {
                    echo "Tamanho da imagem é maior do que o permitido";
                    return false;
                  }
                } else {
                  echo "Ocorreu um erro ao fazer upload da imagem!";
                  return false;
                }
              } else {
                echo "Extensão não permitida!";
                return false;
              }
           } else {$imgNameNew='';}
      
          $sql = sprintf("INSERT INTO usuario (user_nivel, user_nome, user_login, user_senha, user_email, user_foto) 
                                            VALUES (%s, %s, %s, %s, %s, %s)",
                                        GetSQLValueString($_POST['nivel'], "text"),
                                        GetSQLValueString($_POST['nome'], "text"),
                                        GetSQLValueString($_POST['login'], "text"),
                                        GetSQLValueString(md5($_POST['senha']), "text"),
                                        GetSQLValueString($_POST['email'], "text"),
                                        GetSQLValueString($imgNameNew, "text"));
      }
      // Update -------------------------------------------------------------------------------------------
      else if ($_POST['modo'] == 'edicao') {
        // se estiver editando tudo exceto a senha...
        $sqlSenha = '';
        if (isset($_POST['senha'])) 
          $sqlSenha = sprintf(', user_senha=%s', GetSQLValueString(md5($_POST['senha']), "text"));
        
          if (isset($_FILES['foto'])){
            if (isset($_POST['fotoVelha'])) {
              if (file_exists('..imagens/imagens_usuario/'. $_POST['fotoVelha']))
                unlink('..imagens/imagens_usuario' . $_POST['fotoVelha']);
            }
              // pegar o nome do arquivo, name é um atributo de vetor que está salvo
              $imgName = $_FILES['foto']['name'];
              $imgTmpName = $_FILES['foto']['tmp_name'];
              $imgSize = $_FILES['foto']['size'];
              $imgError = $_FILES['foto']['error'];
              $imgType = $_FILES['foto']['type'];

              $imgExt = explode('.', $imgName);
              $imgActualExt = strtolower(end($imgExt));

              // informação das extensões permitidas de arquivo
              $permitido = array('jpg', 'jpeg', 'png', 'pdf');

              // se o tipo da imagem está dentro do permitido 
              if (in_array($imgActualExt, $permitido)) {
                // verificar se não tem erros na imagem
                if ($imgError === 0) {
                  // se o tamanho do arquivo for menor que 50mb
                  if ($imgSize < 100000) {
                    $imgNameNew = str_replace(" ", "", strtolower($_POST['nome'])).".".$imgActualExt;
                    $imgDestination = '../imagens/imagens_usuario/' . $imgNameNew;
                    // Move o arquivo enviado dos arquivos temporarios para o destinatario abaixo
                    move_uploaded_file($imgTmpName, $imgDestination);
                  } else {
                    echo "Tamanho da imagem é maior do que o permitido";
                    return false;
                  }
                } else {
                  echo "Ocorreu um erro ao fazer upload da imagem!";
                  return false;
                }
              } else {
                echo "Extensão não permitida!";
                return false;
              }
          } else {$imgNameNew = '';}


          $sql = sprintf("UPDATE usuario SET user_nivel=%s, user_nome=%s, user_login=%s $sqlSenha, user_email=%s , user_foto=%s
                                        WHERE user_id=%s",
                                        GetSQLValueString($_POST['nivel'], "text"),
                                        GetSQLValueString($_POST['nome'], "text"),
                                        GetSQLValueString($_POST['login'], "text"),
                                        GetSQLValueString($_POST['email'], "text"),
                                        GetSQLValueString($imgNameNew, "text"),
                                        GetSQLValueString($_POST['id'], "text"));
      } 
      // Delete -------------------------------------------------------------------------------------------
      else if ($_POST['modo'] == 'exclusao') {
        $sql = sprintf("DELETE FROM usuario WHERE user_id=%s",
                                        GetSQLValueString($_POST['userId'], "text")); 
      }
      break;
    // ==================================== FIM USUARIO ========================================================

    // ==================================== FUNCIONARIO ===========================================================
    case 'funcionario':
      // Insert -------------------------------------------------------------------------------------------
      if ($_POST['modo'] == 'insercao') {
           
           if (isset($_FILES['foto'])) {
              // pegar o nome do arquivo, name é um atributo de vetor que está salvo
              $imgName = $_FILES['foto']['name'];
              $imgTmpName = $_FILES['foto']['tmp_name'];
              $imgSize = $_FILES['foto']['size'];
              $imgError = $_FILES['foto']['error'];
              $imgType = $_FILES['foto']['type'];

              $imgExt = explode('.', $imgName);
              $imgActualExt = strtolower(end($imgExt));

              // informação das extensões permitidas de arquivo
              $permitido = array('jpg', 'jpeg', 'png', 'pdf');

              // se o tipo da imagem está dentro do permitido 
              if (in_array($imgActualExt, $permitido)) {
                // verificar se não tem erros na imagem
                if ($imgError === 0) {
                  // se o tamanho do arquivo for menor que 50mb
                  if ($imgSize < 100000) {
                    $imgNameNew = str_replace(" ", "", strtolower($_POST['nome'])).".".$imgActualExt;
                    $imgDestination = '../imagens/imagens_funcionario/' . $imgNameNew;
                    // Move o arquivo enviado dos arquivos temporarios para o destinatario abaixo
                    move_uploaded_file($imgTmpName, $imgDestination);
                  } else {
                    echo "Tamanho da imagem é maior do que o permitido";
                    return false;
                  }
                } else {
                  echo "Ocorreu um erro ao fazer upload da imagem!";
                  return false;
                }
              } else {
                echo "Extensão não permitida!";
                return false;
              }
           } else {$imgNameNew='';}
      
          $sql = sprintf("INSERT INTO funcionario (func_nome,func_id_cargo, func_img, func_salario) 
                                            VALUES (%s, %s, %s, %s)",
                                        GetSQLValueString($_POST['nome'], "text"),
                                        GetSQLValueString($_POST['func_id_cargo'], "int"),
                                        GetSQLValueString($imgNameNew, "text"),
                                        GetSQLValueString($_POST['salario'], "text"));
      }
      // Update -------------------------------------------------------------------------------------------
      else if ($_POST['modo'] == 'edicao') {
        
          if (isset($_FILES['foto'])){
            if (isset($_POST['fotoVelha'])) {
              if (file_exists('..imagens/imagens_funcionario/'. $_POST['fotoVelha']))
                unlink('..imagens/imagens_funcionario/' . $_POST['fotoVelha']);
            }
              // pegar o nome do arquivo, name é um atributo de vetor que está salvo
              $imgName = $_FILES['foto']['name'];
              $imgTmpName = $_FILES['foto']['tmp_name'];
              $imgSize = $_FILES['foto']['size'];
              $imgError = $_FILES['foto']['error'];
              $imgType = $_FILES['foto']['type'];

              $imgExt = explode('.', $imgName);
              $imgActualExt = strtolower(end($imgExt));

              // informação das extensões permitidas de arquivo
              $permitido = array('jpg', 'jpeg', 'png', 'pdf');

              // se o tipo da imagem está dentro do permitido 
              if (in_array($imgActualExt, $permitido)) {
                // verificar se não tem erros na imagem
                if ($imgError === 0) {
                  // se o tamanho do arquivo for menor que 50mb
                  if ($imgSize < 100000) {
                    $imgNameNew = str_replace(" ", "", strtolower($_POST['nome'])).".".$imgActualExt;
                    $imgDestination = '../imagens/imagens_funcionario/' . $imgNameNew;
                    // Move o arquivo enviado dos arquivos temporarios para o destinatario abaixo
                    move_uploaded_file($imgTmpName, $imgDestination);
                  } else {
                    echo "Tamanho da imagem é maior do que o permitido";
                    return false;
                  }
                } else {
                  echo "Ocorreu um erro ao fazer upload da imagem!";
                  return false;
                }
              } else {
                echo "Extensão não permitida!";
                return false;
              }
          } else {
          	if (isset($_POST['fotoVelha'])) {
          		$imgNameNew = $_POST['fotoVelha'];
          	} else {$imgNameNew = ' ';}
          }

          echo $sql = sprintf("UPDATE funcionario SET func_nome=%s, func_id_cargo=%s, func_salario=%s, func_img=%s
                                        WHERE func_id=%s;",
                                        GetSQLValueString($_POST['nome'], "text"),
                                        GetSQLValueString($_POST['func_id_cargo'], "int"),
                                        GetSQLValueString($_POST['salario'], "double"),
                                        GetSQLValueString($imgNameNew, "text"),
                                        GetSQLValueString($_POST['id'], "int"));
      } 
      // Delete -------------------------------------------------------------------------------------------
      else if ($_POST['modo'] == 'exclusao') {
        $sql = sprintf("DELETE FROM funcionario WHERE func_id=%s",
                                        GetSQLValueString($_POST['funcId'], "text")); 
      }
      break;
    // ==================================== FIM FUNCIONARIO ========================================================

    // ==================================== CARGO ===========================================================
    case 'cargo':
      // Insert -------------------------------------------------------------------------------------------
      if ($_POST['modo'] == 'insercao') {
      
          $sql = sprintf("INSERT INTO cargo (cargo_nome) VALUES (%s)",GetSQLValueString($_POST['nome'], "text"));
      }
      // Update -------------------------------------------------------------------------------------------
      else if ($_POST['modo'] == 'edicao') {

          $sql = sprintf("UPDATE cargo SET cargo_nome=%s WHERE cargo_id=%s",
                                        GetSQLValueString($_POST['nome'], "text"),
                                        GetSQLValueString($_POST['id'], "text"));
      } 
      // Delete -------------------------------------------------------------------------------------------
      else if ($_POST['modo'] == 'exclusao') {
        $sql = sprintf("DELETE FROM cargo WHERE cargo_id=%s",
                                        GetSQLValueString($_POST['id'], "text")); 
      }
      break;
    // ==================================== FIM CARGO ========================================================

    // ==================================== ESTOQUE ===========================================================
    case 'estoque':
      // Insert -------------------------------------------------------------------------------------------
      if ($_POST['modo'] == 'insercao') {
      
          $sql = sprintf("INSERT INTO estoque (prod_nome, prod_quant) VALUES (%s, %s)",
                          GetSQLValueString($_POST['nome'], "text"),
                          GetSQLValueString($_POST['quantidade'], "double")
                        );
      }
      // Update -------------------------------------------------------------------------------------------
      else if ($_POST['modo'] == 'edicao') {

          $sql = sprintf("UPDATE estoque SET prod_nome=%s, prod_quant=%s WHERE prod_id=%s",
                                        GetSQLValueString($_POST['nome'], "text"),
                                        GetSQLValueString($_POST['quantidade'], "double"),
                                        GetSQLValueString($_POST['id'], "text"));
      } 
      // Delete -------------------------------------------------------------------------------------------
      else if ($_POST['modo'] == 'exclusao') {
        $sql = sprintf("DELETE FROM estoque WHERE prod_id=%s",
                                        GetSQLValueString($_POST['id'], "text")); 
      }
      break;
    // ==================================== FIM ESTOQUE ========================================================

    // ==================================== FILIAL ===========================================================
    case 'filial':
      // Insert -------------------------------------------------------------------------------------------
      if ($_POST['modo'] == 'insercao') {
      
          $sql = sprintf("INSERT INTO filial (filial_nome, filial_endereco) VALUES (%s, %s)",
                          GetSQLValueString($_POST['nome'], "text"),
                          GetSQLValueString($_POST['endereco'], "text")
                        );
      }
      // Update -------------------------------------------------------------------------------------------
      else if ($_POST['modo'] == 'edicao') {

          $sql = sprintf("UPDATE filial SET filial_nome=%s, filial_endereco=%s WHERE filial_id=%s",
                                        GetSQLValueString($_POST['nome'], "text"),
                                        GetSQLValueString($_POST['endereco'], "text"),
                                        GetSQLValueString($_POST['id'], "text"));
      } 
      // Delete -------------------------------------------------------------------------------------------
      else if ($_POST['modo'] == 'exclusao') {
        $sql = sprintf("DELETE FROM filial WHERE filial_id=%s",
                                        GetSQLValueString($_POST['id'], "text")); 
      }
      break;
    // ==================================== FIM FILIAL ========================================================


    

  }
  
    mysql_query($sql, $con) or die(mysql_error());
?>