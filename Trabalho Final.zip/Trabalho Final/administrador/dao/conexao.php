<?php	
	if (!isset($_SESSION)) {
		session_start();
	}
	$con = mysql_connect("localhost", "root", "") or die("Sem conexão com o Banco de Dados.");
	mysql_select_db("alex");
?>