<?php
	$page = explode('/', $_SERVER['PHP_SELF']);
	$page = end($page);

	require_once 'dao/conexao.php';
	$queryTabela = "SELECT * FROM tabelas WHERE tab_status = 1 ORDER BY tab_posit";
	$tabelas = mysql_query($queryTabela, $con) or die(mysql_error());
?>

<div class="col-md-2 sidebar hidden-xs hidden-sm" style="background-color: #4e5765; height: calc(100vh - 51px);">
	<ul class="nav nav-sidebar navegacao" style="padding-top: 10px;">
		<li <?php echo $page=='index.php' ? 'class="active"' : '';?>><a href="index">Início</a></li>
		<?php while ($tabela = mysql_fetch_assoc($tabelas)) { ?>
			<li <?php echo$page==$tabela['tab_nome'].'.php' ? 'class="active"' : '';?>><a href="<?php echo $tabela['tab_nome'] ?>"><?php echo $tabela['tab_titulo'] ?></a></li>
		<?php } ?>
	</ul>
</div>