<?php 
  require_once 'autentica.php';
  require_once 'dao/conexao.php';

  // consulta TOTAL de acessos
  $query_total_acessos = sprintf("SELECT count(*) AS acessos FROM inicial ");
  $total_acessos = mysql_query($query_total_acessos, $con) or die(mysql_error());
  $count_total_acessos = mysql_fetch_assoc($total_acessos);

  // consulta de acessos HOJE
  $query_acessos_hoje = sprintf("SELECT count( * ) AS total_hoje FROM inicial WHERE data = CURDATE( )");
  $acessos_hoje = mysql_query($query_acessos_hoje, $con) or die(mysql_error());
  $hoje = mysql_fetch_assoc($acessos_hoje);

  // consulta de acessos DESKTOP
  $query_acessos_desktop = sprintf("SELECT count(*) AS total_desktop FROM inicial WHERE tipo_dispositivo = 'desktop'");
  $acessos_desktop = mysql_query($query_acessos_desktop, $con) or die(mysql_error());
  $desktop = mysql_fetch_assoc($acessos_desktop);

  // consulta de acessos MOBILE
  $query_acessos_mobile = sprintf("SELECT count(*) AS total_mobile FROM inicial WHERE tipo_dispositivo = 'mobile'");
  $acessos_mobile = mysql_query($query_acessos_mobile, $con) or die(mysql_error());
  $mobile = mysql_fetch_assoc($acessos_mobile);

?>

<div class="text-left">
  <ol class="breadcrumb">
    <li><a href="index.php" class="text-uppercase">home</a></li>
    <li class="active text-uppercase">home</li>
  </ol>
</div>
<div class="titulo">
  <span class="text-uppercase corLaranja">início</span>
</div>
<div class="conteudo-pagina">
  <span class="t18"> Seja bem vindo ao sistema </span> <span class="t18 text-uppercase corLaranja fw700">Orange Panel 3.5</span>
</div>
<div>
  <div class="col-xs-12 col-sm-6 col-md-3">
    <div class="div-acessos" style="border: 2px solid #f73b3b;">
      <div class="corBranco text-uppercase t18" style="background-color: #f73b3b; padding: 10px; min-height: 70px;">
        acessos hoje
      </div>
      <div class="corVermelho t40" style="padding-top: 40px;">
        <?php echo number_format($hoje['total_hoje'],0,'.','.'); ?>
      </div>
    </div>
  </div>
  <div class="col-xs-12 col-sm-6 col-md-3">
    <div class="div-acessos" style="border: 2px solid #428bca;">
      <div class="corBranco text-uppercase t18" style="background-color: #428bca; padding: 10px; min-height: 70px;">
        total de acessos
      </div>
      <div class="corAzulClaro t40" style="padding-top: 40px;">
        <?php echo number_format($count_total_acessos['acessos'],0,'.','.'); ?>
      </div>
    </div>
  </div>
  <div class="col-xs-12 col-sm-6 col-md-3">
    <div class="div-acessos" style="border: 2px solid #e6e600;">
      <div class="corBranco text-uppercase t18" style="background-color: #e6e600; padding: 10px;">
        total via smartphone
      </div>
      <div class="t40" style="padding-top: 40px; color: #e6e600;">
        <?php echo number_format($mobile['total_mobile'],0,'.','.'); ?>
      </div>
    </div>
  </div>
  <div class="col-xs-12 col-sm-6 col-md-3">
    <div class="div-acessos" style="border: 2px solid #019064;">
      <div class="corBranco text-uppercase t18" style="background-color: #019064; padding: 10px;">
        total via computador
      </div>
      <div class="corVerde t40" style="padding-top: 40px;">
        <?php echo number_format($desktop['total_desktop'],0,'.','.'); ?>
      </div>
    </div>
  </div>
</div>